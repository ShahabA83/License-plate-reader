# Car-plate > 2024-08-25 9:56am
https://universe.roboflow.com/shahab-bcv8i/car-plate-pobbc

Provided by a Roboflow user
License: CC BY 4.0

